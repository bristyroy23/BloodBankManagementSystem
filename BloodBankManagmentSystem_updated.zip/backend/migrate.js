// Automatic database update.
// Runs every time the server starts. It only adds what is missing,
// so your existing data is never touched and running it again is safe.
// (It does the same work as frontend/database/migration_donor_matching.sql)

const db = require("./db");
const pdb = db.promise();

async function columnExists(table, column) {
    const [rows] = await pdb.query(
        `SELECT 1 FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
        [table, column]
    );
    return rows.length > 0;
}

async function indexExists(table, indexName) {
    const [rows] = await pdb.query(
        `SELECT 1 FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?`,
        [table, indexName]
    );
    return rows.length > 0;
}

async function addColumn(table, column, definition) {
    if (!(await columnExists(table, column))) {
        await pdb.query(`ALTER TABLE \`${table}\` ADD COLUMN \`${column}\` ${definition}`);
        console.log(`Database updated: added ${table}.${column}`);
    }
}

async function setHospitalPoint(name, lat, lng) {
    await pdb.query(
        `UPDATE hospitals SET latitude = ?, longitude = ?
         WHERE hospital_name = ? AND latitude IS NULL`,
        [lat, lng, name]
    );
}

async function addHospital(name, address, lat, lng) {
    const [rows] = await pdb.query(
        "SELECT 1 FROM hospitals WHERE hospital_name = ?", [name]
    );
    if (rows.length === 0) {
        await pdb.query(
            `INSERT INTO hospitals (hospital_name, phone, address, latitude, longitude)
             VALUES (?, '', ?, ?, ?)`,
            [name, address, lat, lng]
        );
        console.log(`Database updated: added hospital ${name}`);
    }
}

async function migrate() {
    try {
        // Hospitals: map location
        await addColumn("hospitals", "latitude", "DECIMAL(10,7) DEFAULT NULL");
        await addColumn("hospitals", "longitude", "DECIMAL(10,7) DEFAULT NULL");

        // Donors: linked user + location + availability
        await addColumn("donors", "user_id", "INT(11) DEFAULT NULL");
        await addColumn("donors", "latitude", "DECIMAL(10,7) DEFAULT NULL");
        await addColumn("donors", "longitude", "DECIMAL(10,7) DEFAULT NULL");
        await addColumn("donors", "is_available", "TINYINT(1) NOT NULL DEFAULT 1");
        if (!(await indexExists("donors", "uniq_donor_user"))) {
            await pdb.query("ALTER TABLE donors ADD UNIQUE KEY uniq_donor_user (user_id)");
        }

        // Blood requests: details
        await addColumn("blood_requests", "patient_name", "VARCHAR(100) DEFAULT NULL");
        await addColumn("blood_requests", "contact_phone", "VARCHAR(20) DEFAULT NULL");
        await addColumn("blood_requests", "reason", "VARCHAR(255) DEFAULT NULL");
        await addColumn("blood_requests", "urgency", "VARCHAR(10) NOT NULL DEFAULT 'Normal'");
        await addColumn("blood_requests", "needed_by", "DATE DEFAULT NULL");
        await addColumn("blood_requests", "note", "VARCHAR(500) DEFAULT NULL");

        // Donors who say "I can donate"
        await pdb.query(`
            CREATE TABLE IF NOT EXISTS donor_responses (
                id INT(11) NOT NULL AUTO_INCREMENT,
                request_id INT(11) NOT NULL,
                donor_id INT(11) NOT NULL,
                status VARCHAR(15) NOT NULL DEFAULT 'Willing',
                created_at TIMESTAMP NOT NULL DEFAULT current_timestamp(),
                PRIMARY KEY (id),
                UNIQUE KEY uniq_request_donor (request_id, donor_id),
                KEY donor_id (donor_id),
                CONSTRAINT donor_responses_ibfk_1 FOREIGN KEY (request_id)
                    REFERENCES blood_requests (id) ON DELETE CASCADE,
                CONSTRAINT donor_responses_ibfk_2 FOREIGN KEY (donor_id)
                    REFERENCES donors (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);

        // Every user needs a recipient record to ask for blood.
        // Some older users were created without one.
        const [fixed] = await pdb.query(`
            INSERT INTO recipients (name, phone, user_id)
            SELECT u.name, u.phone, u.id FROM users u
            LEFT JOIN recipients r ON r.user_id = u.id
            WHERE r.id IS NULL
        `);
        if (fixed.affectedRows > 0) {
            console.log(`Database updated: created ${fixed.affectedRows} missing recipient record(s)`);
        }

        // Approximate hospital locations (please verify in Admin > Hospitals)
        await setHospitalPoint("Dhaka Medical College Hospital", 23.7256, 90.3972);
        await setHospitalPoint("Square Hospital", 23.7529, 90.3817);
        await setHospitalPoint("Evercare Hospital", 23.8103, 90.4308);
        await addHospital("Chattogram Medical College Hospital", "Panchlaish, Chattogram", 22.3585, 91.8313);
        await addHospital("Parkview Hospital Chattogram", "Pahartali, Chattogram", 22.3622, 91.8200);
        await addHospital("Evercare Hospital Chattogram", "Chattogram", 22.3628, 91.8183);

        console.log("Database is up to date.");
    } catch (error) {
        console.error("Database update failed:", error.message);
    }
}

module.exports = migrate;
