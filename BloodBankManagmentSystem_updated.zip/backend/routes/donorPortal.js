const express = require("express");
const router = express.Router();
const db = require("../db");

const pdb = db.promise();

// A donor must wait this many days between two whole-blood donations.
// Change this number if your blood bank uses a different rule.
const DONATION_GAP_DAYS = 90;

const URGENCY_RANK = { Critical: 0, Urgent: 1, Normal: 2 };

/* ---------------- helpers ---------------- */

function toNum(value) {
    if (value === undefined || value === null || value === "") return null;
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
}

function validLatLng(lat, lng) {
    return (
        lat !== null && lng !== null &&
        lat >= -90 && lat <= 90 &&
        lng >= -180 && lng <= 180
    );
}

const DONOR_SELECT = `
    SELECT
        d.id, d.user_id, d.name, d.phone, d.email, d.age, d.gender,
        d.address, d.blood_group_id, bg.blood_group,
        DATE_FORMAT(d.last_donation, '%Y-%m-%d') AS last_donation,
        DATEDIFF(CURDATE(), d.last_donation) AS days_since,
        DATE_FORMAT(DATE_ADD(d.last_donation, INTERVAL ${DONATION_GAP_DAYS} DAY), '%Y-%m-%d') AS next_eligible_date,
        d.latitude, d.longitude, d.is_available
    FROM donors d
    LEFT JOIN blood_groups bg ON bg.id = d.blood_group_id
`;

function shapeDonor(row) {
    if (!row) return null;
    const eligible = row.days_since === null || row.days_since >= DONATION_GAP_DAYS;
    return {
        id: row.id,
        name: row.name,
        phone: row.phone,
        email: row.email,
        age: row.age,
        gender: row.gender,
        address: row.address,
        blood_group_id: row.blood_group_id,
        blood_group: row.blood_group,
        last_donation: row.last_donation,
        latitude: row.latitude === null ? null : Number(row.latitude),
        longitude: row.longitude === null ? null : Number(row.longitude),
        is_available: !!row.is_available,
        eligible,
        next_eligible_date: eligible ? null : row.next_eligible_date,
        gap_days: DONATION_GAP_DAYS
    };
}

async function getDonorByUser(userId) {
    const [rows] = await pdb.query(DONOR_SELECT + " WHERE d.user_id = ?", [userId]);
    return rows.length ? rows[0] : null;
}

function serverError(res, err, message) {
    console.error(message + ":", err);
    return res.status(500).json({ success: false, message });
}

/* ---------------- donor profile ---------------- */

// Get my donor profile
router.get("/profile/:userId", async (req, res) => {
    const userId = toNum(req.params.userId);
    if (!userId) {
        return res.status(400).json({ success: false, message: "Invalid user" });
    }

    try {
        const row = await getDonorByUser(userId);
        res.json({ success: true, donor: shapeDonor(row) });
    } catch (err) {
        serverError(res, err, "Could not load donor profile");
    }
});

// Create or update my donor profile
router.post("/profile", async (req, res) => {
    const userId = toNum(req.body.user_id);
    const bloodGroup = String(req.body.blood_group || "").trim();
    const age = toNum(req.body.age);
    const gender = String(req.body.gender || "").trim();
    const address = String(req.body.address || "").trim();
    const lastDonation = req.body.last_donation ? String(req.body.last_donation).trim() : null;
    const lat = toNum(req.body.latitude);
    const lng = toNum(req.body.longitude);
    const isAvailable = req.body.is_available === false || req.body.is_available === 0 ? 0 : 1;

    if (!userId) {
        return res.status(400).json({ success: false, message: "Please login again." });
    }
    if (!bloodGroup) {
        return res.status(400).json({ success: false, message: "Please choose your blood group." });
    }
    if (!Number.isInteger(age) || age < 18 || age > 65) {
        return res.status(400).json({
            success: false,
            message: "Donor age must be between 18 and 65."
        });
    }
    if (!["Male", "Female", "Other"].includes(gender)) {
        return res.status(400).json({ success: false, message: "Please choose your gender." });
    }
    if (!address) {
        return res.status(400).json({ success: false, message: "Please enter your address." });
    }
    if (lastDonation) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(lastDonation) || Number.isNaN(Date.parse(lastDonation))) {
            return res.status(400).json({ success: false, message: "Last donation date is not valid." });
        }
        if (Date.parse(lastDonation) > Date.now()) {
            return res.status(400).json({
                success: false,
                message: "Last donation date cannot be in the future."
            });
        }
    }
    if ((lat === null) !== (lng === null) || (lat !== null && !validLatLng(lat, lng))) {
        return res.status(400).json({ success: false, message: "Location is not valid." });
    }

    try {
        const [users] = await pdb.query(
            "SELECT id, name, email, phone FROM users WHERE id = ?",
            [userId]
        );
        if (users.length === 0) {
            return res.status(404).json({ success: false, message: "User not found. Please login again." });
        }
        const user = users[0];

        const [groups] = await pdb.query(
            "SELECT id FROM blood_groups WHERE blood_group = ?",
            [bloodGroup]
        );
        if (groups.length === 0) {
            return res.status(400).json({ success: false, message: "Blood group not found." });
        }
        const bloodGroupId = groups[0].id;

        let donorId;
        const existing = await getDonorByUser(userId);

        if (existing) {
            donorId = existing.id;
        } else {
            // If the admin already added this person as a donor (same email),
            // connect that record instead of creating a duplicate.
            const [sameEmail] = await pdb.query(
                "SELECT id FROM donors WHERE user_id IS NULL AND email = ? LIMIT 1",
                [user.email]
            );
            if (sameEmail.length) donorId = sameEmail[0].id;
        }

        if (donorId) {
            await pdb.query(
                `UPDATE donors SET
                    user_id = ?, name = ?, phone = ?, email = ?, age = ?, gender = ?,
                    blood_group_id = ?, address = ?, last_donation = ?,
                    latitude = ?, longitude = ?, is_available = ?
                 WHERE id = ?`,
                [userId, user.name, user.phone, user.email, age, gender,
                 bloodGroupId, address, lastDonation, lat, lng, isAvailable, donorId]
            );
        } else {
            await pdb.query(
                `INSERT INTO donors
                    (user_id, name, phone, email, age, gender, blood_group_id,
                     address, last_donation, latitude, longitude, is_available)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [userId, user.name, user.phone, user.email, age, gender, bloodGroupId,
                 address, lastDonation, lat, lng, isAvailable]
            );
        }

        const saved = await getDonorByUser(userId);
        res.json({
            success: true,
            message: "Your donor profile is saved.",
            donor: shapeDonor(saved)
        });
    } catch (err) {
        serverError(res, err, "Could not save donor profile");
    }
});

/* ---------------- blood needed for me ---------------- */

// Open blood requests that match my blood group
router.get("/needs/:userId", async (req, res) => {
    const userId = toNum(req.params.userId);
    if (!userId) {
        return res.status(400).json({ success: false, message: "Invalid user" });
    }

    const mode = req.query.match === "exact" ? "exact" : "compatible";

    try {
        const donorRow = await getDonorByUser(userId);
        if (!donorRow) {
            return res.json({ success: true, hasProfile: false, needs: [] });
        }
        const donor = shapeDonor(donorRow);

        const matchSql = mode === "exact"
            ? "br.blood_group_id = ?"
            : `br.blood_group_id IN (
                   SELECT recipient_group_id FROM blood_compatibility
                   WHERE donor_group_id = ?
               )`;

        const sql = `
            SELECT
                br.id, br.quantity, br.status, br.urgency, br.reason,
                br.patient_name, br.contact_phone, br.note,
                br.blood_group_id,
                bg.blood_group,
                DATE_FORMAT(br.request_date, '%Y-%m-%d') AS request_date,
                DATE_FORMAT(br.needed_by, '%Y-%m-%d') AS needed_by,
                h.id AS hospital_id, h.hospital_name,
                h.phone AS hospital_phone, h.address AS hospital_address,
                h.latitude AS hospital_lat, h.longitude AS hospital_lng,
                (SELECT COUNT(*) FROM donor_responses dr
                    WHERE dr.request_id = br.id AND dr.status = 'Willing') AS willing_count,
                (SELECT COUNT(*) FROM donor_responses dr
                    WHERE dr.request_id = br.id AND dr.donor_id = ?
                      AND dr.status = 'Willing') AS responded
            FROM blood_requests br
            JOIN blood_groups bg ON bg.id = br.blood_group_id
            LEFT JOIN hospitals h ON h.id = br.hospital_id
            LEFT JOIN recipients r ON r.id = br.recipient_id
            WHERE br.status IN ('Pending', 'Approved')
              AND COALESCE(br.needed_by, DATE_ADD(br.request_date, INTERVAL 30 DAY)) >= CURDATE()
              AND (r.user_id IS NULL OR r.user_id <> ?)
              AND ${matchSql}
        `;

        const [rows] = await pdb.query(sql, [donor.id, userId, donor.blood_group_id]);

        const needs = rows.map(row => {
            const hLat = toNum(row.hospital_lat);
            const hLng = toNum(row.hospital_lng);
            const hasHospitalPoint = validLatLng(hLat, hLng);

            const responded = row.responded > 0;
            const mapQuery = hasHospitalPoint
                ? `${hLat},${hLng}`
                : encodeURIComponent(`${row.hospital_name || ""} ${row.hospital_address || ""}`.trim());

            return {
                id: row.id,
                blood_group: row.blood_group,
                exact_match: row.blood_group_id === donor.blood_group_id,
                quantity: row.quantity,
                urgency: URGENCY_RANK[row.urgency] === undefined ? "Normal" : row.urgency,
                reason: row.reason,
                patient_name: row.patient_name,
                note: row.note,
                status: row.status,
                request_date: row.request_date,
                needed_by: row.needed_by,
                willing_count: row.willing_count,
                responded,
                // The patient's phone number is shown only after the donor says "I can donate".
                contact_phone: responded ? row.contact_phone : null,
                hospital: {
                    id: row.hospital_id,
                    name: row.hospital_name,
                    phone: row.hospital_phone,
                    address: row.hospital_address,
                    latitude: hasHospitalPoint ? hLat : null,
                    longitude: hasHospitalPoint ? hLng : null
                },
                map_url: mapQuery
                    ? `https://www.google.com/maps/search/?api=1&query=${mapQuery}`
                    : null,
                directions_url: mapQuery
                    ? `https://www.google.com/maps/dir/?api=1&destination=${mapQuery}`
                    : null
            };
        });

        needs.sort((a, b) => {
            const u = URGENCY_RANK[a.urgency] - URGENCY_RANK[b.urgency];
            if (u !== 0) return u;
            if (a.exact_match !== b.exact_match) return a.exact_match ? -1 : 1;
            return b.id - a.id;
        });

        res.json({
            success: true,
            hasProfile: true,
            donor,
            match: mode,
            needs
        });
    } catch (err) {
        serverError(res, err, "Could not load blood needs");
    }
});

/* ---------------- "I can donate" ---------------- */

router.post("/respond", async (req, res) => {
    const userId = toNum(req.body.user_id);
    const requestId = toNum(req.body.request_id);
    const cancel = req.body.action === "cancel";

    if (!userId || !requestId) {
        return res.status(400).json({ success: false, message: "Missing information." });
    }

    try {
        const donorRow = await getDonorByUser(userId);
        if (!donorRow) {
            return res.status(400).json({
                success: false,
                message: "Please create your donor profile first."
            });
        }
        const donor = shapeDonor(donorRow);

        if (cancel) {
            await pdb.query(
                "DELETE FROM donor_responses WHERE request_id = ? AND donor_id = ?",
                [requestId, donor.id]
            );
            return res.json({ success: true, message: "You are no longer listed for this request." });
        }

        if (!donor.is_available) {
            return res.status(400).json({
                success: false,
                message: "Your profile is set to 'not available'. Turn it on in your donor profile first."
            });
        }
        if (!donor.eligible) {
            return res.status(400).json({
                success: false,
                message: `You donated recently. You can donate again from ${donor.next_eligible_date}.`
            });
        }

        const [requests] = await pdb.query(
            `SELECT br.id, br.blood_group_id, br.contact_phone, br.patient_name, br.status,
                    r.user_id AS requester_user_id
             FROM blood_requests br
             LEFT JOIN recipients r ON r.id = br.recipient_id
             WHERE br.id = ?`,
            [requestId]
        );
        if (requests.length === 0) {
            return res.status(404).json({ success: false, message: "Request not found." });
        }
        const request = requests[0];

        if (!["Pending", "Approved"].includes(request.status)) {
            return res.status(400).json({ success: false, message: "This request is already closed." });
        }
        if (request.requester_user_id === userId) {
            return res.status(400).json({ success: false, message: "You cannot donate to your own request." });
        }

        const [compatible] = await pdb.query(
            `SELECT 1 FROM blood_compatibility
             WHERE recipient_group_id = ? AND donor_group_id = ? LIMIT 1`,
            [request.blood_group_id, donor.blood_group_id]
        );
        if (compatible.length === 0) {
            return res.status(400).json({
                success: false,
                message: "Your blood group cannot be given to this patient."
            });
        }

        await pdb.query(
            `INSERT INTO donor_responses (request_id, donor_id, status)
             VALUES (?, ?, 'Willing')
             ON DUPLICATE KEY UPDATE status = 'Willing'`,
            [requestId, donor.id]
        );

        res.json({
            success: true,
            message: "Thank you! The patient's family can now see your contact details.",
            contact_phone: request.contact_phone,
            patient_name: request.patient_name
        });
    } catch (err) {
        serverError(res, err, "Could not save your response");
    }
});

module.exports = router;
