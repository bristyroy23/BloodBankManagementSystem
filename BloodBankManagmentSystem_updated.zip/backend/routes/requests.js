
const express = require("express");
const router = express.Router();
const db = require("../db");

// Load Blood Groups and Hospitals
router.get("/options", (req, res) => {
    db.query(
        "SELECT id, blood_group FROM blood_groups",
        (err, bloodGroups) => {
            if (err) {
                console.log("Blood Group Error:", err);
                return res.status(500).json({
                    success: false,
                    message: "Blood groups loading failed",
                    error: err.message
                });
            }

            db.query(
                "SELECT id, hospital_name, address FROM hospitals ORDER BY hospital_name, id",
                (err, hospitals) => {
                    if (err) {
                        console.log("Hospital Error:", err);
                        return res.status(500).json({
                            success: false,
                            message: "Hospitals loading failed",
                            error: err.message
                        });
                    }

                    res.json({
                        success: true,
                        bloodGroups,
                        hospitals
                    });
                }
            );
        }
    );
});

// Submit Blood Request
router.post("/add", (req, res) => {
    const {
        recipient_id,
        blood_group_id,
        hospital_id,
        quantity,
        request_date,
        patient_name,
        contact_phone,
        reason,
        urgency,
        needed_by,
        note
    } = req.body;

    if (
        !recipient_id ||
        !blood_group_id ||
        !hospital_id ||
        !quantity
    ) {
        return res.status(400).json({
            success: false,
            message: "All fields are required"
        });
    }

    const units = Number(quantity);
    if (!Number.isInteger(units) || units < 1 || units > 20) {
        return res.status(400).json({
            success: false,
            message: "Units must be a number between 1 and 20"
        });
    }

    const urgencyValue = ["Normal", "Urgent", "Critical"].includes(urgency)
        ? urgency
        : "Normal";

    const sql = `
        INSERT INTO blood_requests
        (recipient_id, blood_group_id, hospital_id,
         quantity, request_date, status,
         patient_name, contact_phone, reason, urgency, needed_by, note)
        VALUES (?, ?, ?, ?, COALESCE(?, CURDATE()), ?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(sql, [
        recipient_id,
        blood_group_id,
        hospital_id,
        units,
        request_date || null,
        "Pending",
        patient_name ? String(patient_name).trim().slice(0, 100) : null,
        contact_phone ? String(contact_phone).trim().slice(0, 20) : null,
        reason ? String(reason).trim().slice(0, 255) : null,
        urgencyValue,
        needed_by || null,
        note ? String(note).trim().slice(0, 500) : null
    ], (err, result) => {
        if (err) {
            console.log("Blood Request Error:", err);
            return res.status(500).json({
                success: false,
                message: "Request submit failed",
                error: err.message
            });
        }

        res.json({
            success: true,
            message: "Blood request submitted successfully!",
            requestId: result.insertId
        });
    });
});

// Get All Blood Requests (Admin)
router.get("/all", (req, res) => {
    const sql = `
        SELECT
            br.id,
            r.name AS recipient_name,
            bg.blood_group,
            br.quantity,
            h.hospital_name,
            br.request_date,
            br.status,
            br.patient_name,
            br.reason,
            br.urgency,
            DATE_FORMAT(br.needed_by, '%Y-%m-%d') AS needed_by,
            (SELECT COUNT(*) FROM donor_responses dr
                WHERE dr.request_id = br.id AND dr.status = 'Willing') AS willing_count
        FROM blood_requests br
        LEFT JOIN recipients r
            ON br.recipient_id = r.id
        LEFT JOIN blood_groups bg
            ON br.blood_group_id = bg.id
        LEFT JOIN hospitals h
            ON br.hospital_id = h.id
        ORDER BY br.id DESC
    `;

    db.query(sql, (err, results) => {
        if (err) {
            console.log("All Requests Error:", err);
            return res.status(500).json({
                success: false,
                message: "Could not load all requests"
            });
        }

        res.json({
            success: true,
            requests: results
        });
    });
});

// Update Blood Request Status (Admin)
router.put("/status/:id", (req, res) => {
    const { status } = req.body;
    const requestId = req.params.id;

    if (!["Pending", "Approved", "Rejected", "Fulfilled"].includes(status)) {
        return res.status(400).json({
            success: false,
            message: "Invalid status"
        });
    }

    db.query(
        "UPDATE blood_requests SET status = ? WHERE id = ?",
        [status, requestId],
        (err, result) => {
            if (err) {
                console.log("Status Update Error:", err);
                return res.status(500).json({
                    success: false,
                    message: "Status update failed"
                });
            }

            if (result.affectedRows === 0) {
                return res.status(404).json({
                    success: false,
                    message: "Request not found"
                });
            }

            res.json({
                success: true,
                message: "Request status updated successfully!"
            });
        }
    );
});

// Get My Blood Requests
router.get("/my/:recipientId", (req, res) => {
    const recipientId = req.params.recipientId;

    const sql = `
        SELECT
            br.id,
            bg.blood_group,
            br.quantity,
            h.hospital_name,
            br.request_date,
            br.status,
            br.patient_name,
            br.reason,
            br.urgency,
            DATE_FORMAT(br.needed_by, '%Y-%m-%d') AS needed_by,
            (SELECT COUNT(*) FROM donor_responses dr
                WHERE dr.request_id = br.id AND dr.status = 'Willing') AS willing_count
        FROM blood_requests br
        LEFT JOIN blood_groups bg
            ON br.blood_group_id = bg.id
        LEFT JOIN hospitals h
            ON br.hospital_id = h.id
        WHERE br.recipient_id = ?
        ORDER BY br.id DESC
    `;

    db.query(sql, [recipientId], (err, results) => {
        if (err) {
            console.log("My Requests Error:", err);
            return res.status(500).json({
                success: false,
                message: "Could not load requests"
            });
        }

        res.json({
            success: true,
            requests: results
        });
    });
});
// Make sure a logged-in user has a recipient record (needed to ask for blood)
router.post("/ensure-recipient", (req, res) => {
    const userId = req.body.user_id;

    if (!userId) {
        return res.status(400).json({ success: false, message: "Please login again." });
    }

    db.query("SELECT id FROM recipients WHERE user_id = ?", [userId], (err, rows) => {
        if (err) {
            return res.status(500).json({ success: false, message: "Could not check your account" });
        }
        if (rows.length > 0) {
            return res.json({ success: true, recipientId: rows[0].id });
        }

        db.query(
            `INSERT INTO recipients (name, phone, user_id)
             SELECT name, phone, id FROM users WHERE id = ?`,
            [userId],
            (insertErr, result) => {
                if (insertErr || result.affectedRows === 0) {
                    return res.status(400).json({
                        success: false,
                        message: "Account not found. Please login again."
                    });
                }
                res.json({ success: true, recipientId: result.insertId });
            }
        );
    });
});

// Donors who said "I can donate" for one of my requests
router.get("/donors/:requestId", (req, res) => {
    const requestId = req.params.requestId;
    const recipientId = req.query.recipient_id;

    const sql = `
        SELECT d.name, d.phone, d.address, bg.blood_group,
               DATE_FORMAT(dr.created_at, '%Y-%m-%d') AS responded_on
        FROM donor_responses dr
        JOIN blood_requests br ON br.id = dr.request_id
        JOIN donors d ON d.id = dr.donor_id
        LEFT JOIN blood_groups bg ON bg.id = d.blood_group_id
        WHERE dr.request_id = ?
          AND br.recipient_id = ?
          AND dr.status = 'Willing'
        ORDER BY dr.created_at ASC
    `;

    db.query(sql, [requestId, recipientId], (err, rows) => {
        if (err) {
            console.log("Request Donors Error:", err);
            return res.status(500).json({
                success: false,
                message: "Could not load donors"
            });
        }

        res.json({ success: true, donors: rows });
    });
});

module.exports = router;
