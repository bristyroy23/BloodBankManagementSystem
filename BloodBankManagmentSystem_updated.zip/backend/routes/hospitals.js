const express = require("express");
const router = express.Router();
const db = require("../db");
const verifyAdmin = require("../middleware/auth");

function toNum(v) {
    if (v === undefined || v === null || v === "") return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
}

function readBody(body) {
    const name = String(body.hospital_name || "").trim();
    const phone = String(body.phone || "").trim();
    const address = String(body.address || "").trim();
    const lat = toNum(body.latitude);
    const lng = toNum(body.longitude);

    if (!name || !address) {
        return { error: "Hospital name and address are required." };
    }
    if ((lat === null) !== (lng === null)) {
        return { error: "Enter both latitude and longitude, or leave both empty." };
    }
    if (lat !== null && (lat < -90 || lat > 90 || lng < -180 || lng > 180)) {
        return { error: "Latitude or longitude is not valid." };
    }
    return { name, phone, address, lat, lng };
}

// List hospitals (used by forms and the hospital page)
router.get("/all", (req, res) => {
    db.query(
        `SELECT id, hospital_name, phone, address, latitude, longitude
         FROM hospitals ORDER BY hospital_name, id`,
        (err, rows) => {
            if (err) {
                return res.status(500).json({ success: false, message: "Could not load hospitals" });
            }
            res.json({ success: true, hospitals: rows });
        }
    );
});

// Add hospital (admin)
router.post("/add", verifyAdmin, (req, res) => {
    const d = readBody(req.body);
    if (d.error) return res.status(400).json({ success: false, message: d.error });

    db.query(
        `INSERT INTO hospitals (hospital_name, phone, address, latitude, longitude)
         VALUES (?, ?, ?, ?, ?)`,
        [d.name, d.phone, d.address, d.lat, d.lng],
        (err, result) => {
            if (err) {
                console.error("Hospital add error:", err);
                return res.status(500).json({ success: false, message: "Could not add hospital" });
            }
            res.json({ success: true, message: "Hospital added.", id: result.insertId });
        }
    );
});

// Update hospital (admin)
router.put("/update/:id", verifyAdmin, (req, res) => {
    const d = readBody(req.body);
    if (d.error) return res.status(400).json({ success: false, message: d.error });

    db.query(
        `UPDATE hospitals SET hospital_name = ?, phone = ?, address = ?,
                latitude = ?, longitude = ? WHERE id = ?`,
        [d.name, d.phone, d.address, d.lat, d.lng, req.params.id],
        (err, result) => {
            if (err) {
                console.error("Hospital update error:", err);
                return res.status(500).json({ success: false, message: "Could not update hospital" });
            }
            if (result.affectedRows === 0) {
                return res.status(404).json({ success: false, message: "Hospital not found" });
            }
            res.json({ success: true, message: "Hospital updated." });
        }
    );
});

// Delete hospital (admin)
router.delete("/delete/:id", verifyAdmin, (req, res) => {
    db.query("DELETE FROM hospitals WHERE id = ?", [req.params.id], (err, result) => {
        if (err) {
            if (err.code === "ER_ROW_IS_REFERENCED_2") {
                return res.status(409).json({
                    success: false,
                    message: "This hospital has blood requests, so it cannot be deleted."
                });
            }
            console.error("Hospital delete error:", err);
            return res.status(500).json({ success: false, message: "Could not delete hospital" });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ success: false, message: "Hospital not found" });
        }
        res.json({ success: true, message: "Hospital deleted." });
    });
});

module.exports = router;
