// Shared helpers used by the newer pages.
// Include with:  <script src="script.js"></script>  (before the page's own script)

const API_BASE = "http://localhost:5000/api";

function escapeHTML(value) {
    return String(value === undefined || value === null ? "" : value)
        .replace(/[&<>"']/g, char => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        })[char]);
}

function getUser() {
    try {
        return JSON.parse(localStorage.getItem("user"));
    } catch (e) {
        return null;
    }
}

// Send the visitor to the login page if they are not logged in as `role`.
// Returns the saved account (or null when redirecting).
function requireRole(role) {
    const account = getUser();
    if (!account || localStorage.getItem("role") !== role) {
        window.location.href = "login.html";
        return null;
    }
    return account;
}

function logout() {
    localStorage.removeItem("user");
    localStorage.removeItem("role");
    localStorage.removeItem("adminToken");
    window.location.href = "login.html";
}

// "2026-11-25" -> "25 Nov 2026"
function formatDate(value) {
    if (!value) return "";
    const text = String(value).slice(0, 10);
    const d = new Date(text + "T00:00:00");
    if (Number.isNaN(d.getTime())) return text;
    return d.toLocaleDateString("en-GB", {
        day: "numeric", month: "short", year: "numeric"
    });
}

function urgencyBadge(urgency) {
    const cls = (urgency || "Normal").toLowerCase();
    const label = urgency === "Critical" ? "Critical - needed now"
                : urgency === "Urgent" ? "Urgent"
                : "Normal";
    return `<span class="badge ${escapeHTML(cls)}">${escapeHTML(label)}</span>`;
}

function statusBadge(status) {
    const s = status || "Pending";
    return `<span class="badge ${escapeHTML(s.toLowerCase())}">${escapeHTML(s)}</span>`;
}

// Ask the browser for the current location.
// Gives a clear reason when it does not work.
function getMyLocation() {
    return new Promise((resolve, reject) => {
        if (!window.isSecureContext) {
            reject(new Error(
                "The browser blocks location on this address. Open the site as " +
                "http://localhost:5000/frontend/login.html (not by double-clicking the file), " +
                "or pick your area from the list instead."
            ));
            return;
        }
        if (!navigator.geolocation) {
            reject(new Error("This browser cannot share your location. Please pick your area from the list."));
            return;
        }

        const done = pos => resolve({
            latitude: Number(pos.coords.latitude.toFixed(6)),
            longitude: Number(pos.coords.longitude.toFixed(6))
        });

        const fail = err => {
            let text = "Could not get your location. Please pick your area from the list.";
            if (err && err.code === 1) {
                text = "Location is blocked. Click the lock icon next to the web address, " +
                       "allow Location, then try again. Or pick your area from the list.";
            } else if (err && err.code === 2) {
                text = "Your device could not find its location. Turn on Location/GPS, " +
                       "or pick your area from the list.";
            } else if (err && err.code === 3) {
                text = "Finding your location took too long. Try again, or pick your area from the list.";
            }
            reject(new Error(text));
        };

        // First try the quick method, then the GPS method.
        navigator.geolocation.getCurrentPosition(done, err => {
            if (err && err.code === 1) return fail(err);
            navigator.geolocation.getCurrentPosition(done, fail, {
                enableHighAccuracy: true,
                timeout: 20000
            });
        }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 });
    });
}

// Approximate centre of some Chattogram areas.
// Used when the browser cannot share the exact location.
const AREA_PRESETS = [
    ["Agrabad", 22.3250, 91.8120],
    ["Bahaddarhat", 22.3680, 91.8350],
    ["Bayezid", 22.3920, 91.8250],
    ["Chandgaon", 22.3770, 91.8650],
    ["Chawkbazar", 22.3590, 91.8400],
    ["Double Mooring", 22.3300, 91.8000],
    ["GEC Circle", 22.3590, 91.8210],
    ["Halishahar", 22.3340, 91.7840],
    ["Kotwali / Andarkilla", 22.3400, 91.8330],
    ["Khulshi", 22.3620, 91.8100],
    ["Muradpur", 22.3640, 91.8380],
    ["Nasirabad", 22.3700, 91.8240],
    ["Pahartali", 22.3650, 91.7950],
    ["Panchlaish", 22.3600, 91.8300],
    ["Patenga", 22.2420, 91.8000],
    ["Sholoshahar", 22.3570, 91.8240]
];

function areaOptionsHTML() {
    return '<option value="">Or choose your area (Chattogram)</option>' +
        AREA_PRESETS.map((a, i) => `<option value="${i}">${escapeHTML(a[0])}</option>`).join("");
}

function areaPoint(index) {
    const a = AREA_PRESETS[Number(index)];
    return a ? { latitude: a[1], longitude: a[2] } : null;
}

// Make sure the logged-in user has a recipient record (needed to ask for blood).
// Returns the recipient id, or null if it could not be found.
async function ensureRecipientId() {
    const account = getUser();
    if (!account) return null;
    if (account.recipientId) return account.recipientId;

    try {
        const response = await fetch(API_BASE + "/requests/ensure-recipient", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ user_id: account.id })
        });
        const data = await response.json();
        if (data.success && data.recipientId) {
            account.recipientId = data.recipientId;
            localStorage.setItem("user", JSON.stringify(account));
            return data.recipientId;
        }
    } catch (e) {
        console.error(e);
    }
    return null;
}
