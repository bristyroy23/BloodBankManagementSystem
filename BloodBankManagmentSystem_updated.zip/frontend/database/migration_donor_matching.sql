-- ============================================================
-- Blood Bank: Donor Matching Update
-- Run this ONCE on your existing `bloodbankmanagement` database
-- (phpMyAdmin -> select database -> Import / SQL tab).
-- Your old data is kept. It is safe to run again (nothing breaks).
-- ============================================================

-- 1) Hospitals: add map location (latitude / longitude)
ALTER TABLE `hospitals`
  ADD COLUMN IF NOT EXISTS `latitude`  DECIMAL(10,7) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `longitude` DECIMAL(10,7) DEFAULT NULL;

-- 2) Donors: link a donor to a logged-in user + save donor location
ALTER TABLE `donors`
  ADD COLUMN IF NOT EXISTS `user_id`      INT(11)       DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `latitude`     DECIMAL(10,7) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `longitude`    DECIMAL(10,7) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `is_available` TINYINT(1)    NOT NULL DEFAULT 1;

-- one donor profile per user
ALTER TABLE `donors`
  ADD UNIQUE KEY IF NOT EXISTS `uniq_donor_user` (`user_id`);

-- 3) Blood requests: why / how urgent / who is the patient
ALTER TABLE `blood_requests`
  ADD COLUMN IF NOT EXISTS `patient_name`  VARCHAR(100) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `contact_phone` VARCHAR(20)  DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `reason`        VARCHAR(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `urgency`       VARCHAR(10)  NOT NULL DEFAULT 'Normal',
  ADD COLUMN IF NOT EXISTS `needed_by`     DATE         DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `note`          VARCHAR(500) DEFAULT NULL;

-- 4) New table: donors who say "I can donate" for a request
CREATE TABLE IF NOT EXISTS `donor_responses` (
  `id`         INT(11)     NOT NULL AUTO_INCREMENT,
  `request_id` INT(11)     NOT NULL,
  `donor_id`   INT(11)     NOT NULL,
  `status`     VARCHAR(15) NOT NULL DEFAULT 'Willing',
  `created_at` TIMESTAMP   NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_request_donor` (`request_id`, `donor_id`),
  KEY `donor_id` (`donor_id`),
  CONSTRAINT `donor_responses_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `blood_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `donor_responses_ibfk_2` FOREIGN KEY (`donor_id`)   REFERENCES `donors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 5) Hospital locations (APPROXIMATE - please verify on Google Maps
--    and correct them from Admin > Hospitals)
UPDATE `hospitals` SET `latitude` = 23.7256, `longitude` = 90.3972
  WHERE `hospital_name` = 'Dhaka Medical College Hospital' AND `latitude` IS NULL;
UPDATE `hospitals` SET `latitude` = 23.7529, `longitude` = 90.3817
  WHERE `hospital_name` = 'Square Hospital' AND `latitude` IS NULL;
UPDATE `hospitals` SET `latitude` = 23.8103, `longitude` = 90.4308
  WHERE `hospital_name` = 'Evercare Hospital' AND `latitude` IS NULL;

-- Chattogram hospitals (approximate locations)
INSERT INTO `hospitals` (`hospital_name`, `phone`, `address`, `latitude`, `longitude`)
SELECT 'Chattogram Medical College Hospital', '', 'Panchlaish, Chattogram', 22.3585, 91.8313
WHERE NOT EXISTS (SELECT 1 FROM `hospitals` WHERE `hospital_name` = 'Chattogram Medical College Hospital');

INSERT INTO `hospitals` (`hospital_name`, `phone`, `address`, `latitude`, `longitude`)
SELECT 'Parkview Hospital Chattogram', '', 'Pahartali, Chattogram', 22.3622, 91.8200
WHERE NOT EXISTS (SELECT 1 FROM `hospitals` WHERE `hospital_name` = 'Parkview Hospital Chattogram');

INSERT INTO `hospitals` (`hospital_name`, `phone`, `address`, `latitude`, `longitude`)
SELECT 'Evercare Hospital Chattogram', '', 'Chattogram', 22.3628, 91.8183
WHERE NOT EXISTS (SELECT 1 FROM `hospitals` WHERE `hospital_name` = 'Evercare Hospital Chattogram');
