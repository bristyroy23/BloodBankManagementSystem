-- Blood Bank Management System: FULL database (includes Donor Matching update)
-- Import into an empty database named bloodbankmanagement.

/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES
(1,'Admin','admin@gmail.com','$2b$10$f/t1uhBdK/Ea9UQYtCJhge20q5RG62SZX79hr84RL2thSFiJEByrW');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
DROP TABLE IF EXISTS `blood_compatibility`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blood_compatibility` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_group_id` int(11) DEFAULT NULL,
  `donor_group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recipient_group_id` (`recipient_group_id`),
  KEY `donor_group_id` (`donor_group_id`),
  CONSTRAINT `blood_compatibility_ibfk_1` FOREIGN KEY (`recipient_group_id`) REFERENCES `blood_groups` (`id`),
  CONSTRAINT `blood_compatibility_ibfk_2` FOREIGN KEY (`donor_group_id`) REFERENCES `blood_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `blood_compatibility` DISABLE KEYS */;
INSERT INTO `blood_compatibility` VALUES
(1,1,1),
(2,1,2),
(3,1,7),
(4,1,8),
(5,2,2),
(6,2,8),
(7,3,3),
(8,3,4),
(9,3,7),
(10,3,8),
(11,4,4),
(12,4,8),
(13,5,1),
(14,5,2),
(15,5,3),
(16,5,4),
(17,5,5),
(18,5,6),
(19,5,7),
(20,5,8),
(21,6,2),
(22,6,4),
(23,6,6),
(24,6,8),
(25,7,7),
(26,7,8),
(27,8,8);
/*!40000 ALTER TABLE `blood_compatibility` ENABLE KEYS */;
DROP TABLE IF EXISTS `blood_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blood_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blood_group` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `blood_groups` DISABLE KEYS */;
INSERT INTO `blood_groups` VALUES
(1,'A+'),
(2,'A-'),
(3,'B+'),
(4,'B-'),
(5,'AB+'),
(6,'AB-'),
(7,'O+'),
(8,'O-');
/*!40000 ALTER TABLE `blood_groups` ENABLE KEYS */;
DROP TABLE IF EXISTS `blood_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blood_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_id` int(11) DEFAULT NULL,
  `blood_group_id` int(11) DEFAULT NULL,
  `hospital_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `patient_name` varchar(100) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `urgency` varchar(10) NOT NULL DEFAULT 'Normal',
  `needed_by` date DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recipient_id` (`recipient_id`),
  KEY `blood_group_id` (`blood_group_id`),
  KEY `hospital_id` (`hospital_id`),
  CONSTRAINT `blood_requests_ibfk_1` FOREIGN KEY (`recipient_id`) REFERENCES `recipients` (`id`),
  CONSTRAINT `blood_requests_ibfk_2` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`),
  CONSTRAINT `blood_requests_ibfk_3` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `blood_requests` DISABLE KEYS */;
INSERT INTO `blood_requests` VALUES
(1,2,3,3,2,'2023-11-09','Pending',NULL,NULL,NULL,'Normal',NULL,NULL),
(2,2,5,1,2,'2026-11-11','Approved',NULL,NULL,NULL,'Normal',NULL,NULL);
/*!40000 ALTER TABLE `blood_requests` ENABLE KEYS */;
DROP TABLE IF EXISTS `blood_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `blood_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blood_group_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `blood_group_id` (`blood_group_id`),
  CONSTRAINT `blood_stock_ibfk_1` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `blood_stock` DISABLE KEYS */;
INSERT INTO `blood_stock` VALUES
(1,1,10),
(2,2,1),
(3,3,0),
(4,4,1),
(5,5,0),
(6,6,0),
(7,7,0),
(8,8,2);
/*!40000 ALTER TABLE `blood_stock` ENABLE KEYS */;
DROP TABLE IF EXISTS `donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `donations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_id` int(11) DEFAULT NULL,
  `blood_group_id` int(11) DEFAULT NULL,
  `donation_date` date DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `donor_id` (`donor_id`),
  KEY `blood_group_id` (`blood_group_id`),
  CONSTRAINT `donations_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `donors` (`id`),
  CONSTRAINT `donations_ibfk_2` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `donations` DISABLE KEYS */;
/*!40000 ALTER TABLE `donations` ENABLE KEYS */;
DROP TABLE IF EXISTS `donor_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `donor_responses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `status` varchar(15) NOT NULL DEFAULT 'Willing',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_request_donor` (`request_id`,`donor_id`),
  KEY `donor_id` (`donor_id`),
  CONSTRAINT `donor_responses_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `blood_requests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `donor_responses_ibfk_2` FOREIGN KEY (`donor_id`) REFERENCES `donors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `donor_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `donor_responses` ENABLE KEYS */;
DROP TABLE IF EXISTS `donors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `donors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `blood_group_id` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `last_donation` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_donor_user` (`user_id`),
  KEY `blood_group_id` (`blood_group_id`),
  CONSTRAINT `donors_ibfk_1` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `donors` DISABLE KEYS */;
INSERT INTO `donors` VALUES
(2,'Bristy Roy','01835010547',23,'Female',3,'Feni','2003-01-01','bristy651@gmail.com',NULL,NULL,NULL,1),
(3,'abida','018350140254',24,'Female',7,'Chattagram','2001-12-31','abida123@gmail.com',NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `donors` ENABLE KEYS */;
DROP TABLE IF EXISTS `hospitals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hospitals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_name` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `hospitals` DISABLE KEYS */;
INSERT INTO `hospitals` VALUES
(1,'Dhaka Medical College Hospital','01700000000','Dhaka, Bangladesh',23.7256000,90.3972000),
(2,'Square Hospital','01800000000','Panthapath, Dhaka',23.7529000,90.3817000),
(3,'Evercare Hospital','01900000000','Bashundhara, Dhaka',23.8103000,90.4308000),
(4,'Dhaka Medical College Hospital','01700000000','Dhaka, Bangladesh',23.7256000,90.3972000),
(5,'Square Hospital','01800000000','Panthapath, Dhaka',23.7529000,90.3817000),
(6,'Evercare Hospital','01900000000','Bashundhara, Dhaka',23.8103000,90.4308000),
(7,'Chattogram Medical College Hospital','','Panchlaish, Chattogram',22.3585000,91.8313000),
(8,'Parkview Hospital Chattogram','','Pahartali, Chattogram',22.3622000,91.8200000),
(9,'Evercare Hospital Chattogram','','Chattogram',22.3628000,91.8183000);
/*!40000 ALTER TABLE `hospitals` ENABLE KEYS */;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES
(5,'admin@gmail.com','admin','0d4d24cc1470d36ad711724872b6263df3ee843f893d1b9c7b9fada3474db740','2026-11-08 11:51:19',NULL,'2026-11-08 05:36:19');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
DROP TABLE IF EXISTS `recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recipients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `recipients` DISABLE KEYS */;
INSERT INTO `recipients` VALUES
(1,'Rakib','01835010264',NULL,NULL,NULL,6),
(2,'Rahima','01356010547',25,'Female','dhaka',7);
/*!40000 ALTER TABLE `recipients` ENABLE KEYS */;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'bristy','bristy@gmail.com','01835010542','$2b$10$qCNPVY4xx6Opp9NV5PP1feVMjjKZyzos0hSaZvVavTt5.d1DbAdHe','2026-11-04 06:12:15'),
(2,'Abida','abida@gmial.com','01836250101','$2b$10$0SyloNwzj6Pu1DigkAa18Oitb3IjjncA/4qWNo89UYWc9mmdYNJbW','2026-11-04 06:59:31'),
(3,'Abida','akash@gmail.com','01835010574','$2b$10$RfJuAR0rGa0wxobwppeDH.w4OHMZT9HIM3hUvXoe/mMAZeiKJxmq6','2026-11-04 07:01:41'),
(5,'akash','akash123@gmail.com','01835010253','$2b$10$9XCuvEDSf7cAhoE0RMxJ7uW04g0wHrmSK9iLkcW2LUQxYXJS.pQjS','2026-11-08 06:31:36'),
(6,'Rakib','rakib@gmail.com','01835010264','$2b$10$0AG/09/TjHr5AWsqzkntNOA/nlMjkDLFIhzvZMbrgCkXtTFy4Q6Qu','2026-11-08 10:41:51'),
(7,'Rahima','rahima@gmail.com','01356010547','$2b$10$/5hpLkfNoW2ZU6s3eb702.waY25o122Ky4RhuSgv5Yoh2QR9SNsl.','2026-11-09 08:15:55');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

